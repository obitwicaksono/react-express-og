/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO,ONLY_FULL_GROUP_BY,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `users` VALUES(1,"John Doe","john.doe@example.com","Jl. Sudirman No. 1, Jakarta","2025-07-10 00:48:53","2025-07-10 00:48:53")
,(2,"Jane Smith","jane.smith@example.com","Jl. Thamrin No. 2, Jakarta","2025-07-10 00:48:53","2025-07-10 00:48:53")
,(3,"Ahmad Wijaya","ahmad.wijaya@example.com","Jl. Malioboro No. 3, Yogyakarta","2025-07-10 00:48:53","2025-07-10 00:48:53")
,(8,"Robertho Wicaksono","obit@mail.com","Jl. Banaran No.120\nRT 10 RW 04","2025-07-10 00:54:20","2025-07-10 00:54:20")
;
